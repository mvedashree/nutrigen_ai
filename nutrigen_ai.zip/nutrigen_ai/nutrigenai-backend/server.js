require('dotenv').config();
const express = require('express');
const cors = require('cors');
const {
    GoogleGenerativeAI
} = require("@google/generative-ai");

const app = express();
const port = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

//Tell express where the files are located
app.use(express.static("./NutrigenAi-Backend")); //To serve static files

// Initialize Gemini AI *only if* the API key is present
let genAI;
if (process.env.GEMINI_API_KEY) {
    genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
} else {
    console.error("GEMINI_API_KEY is not set in the .env file!  The server will not be able to call the Gemini API.");
}

// Nutritional Information Endpoint
app.get('/api/nutrition', async (req, res) => {
    if (!genAI) {
        return res.status(500).json({
            error: "Gemini API key is not configured.  Cannot call the Gemini API."
        });
    }

    const food = req.query.food;
    console.log(`Received request for nutritional information about: ${food}`);

    if (!food) {
        return res.status(400).json({
            error: "Food name is required"
        });
    }

    try {
        const model = genAI.getGenerativeModel({
            model: "gemini-pro"
        });
        const prompt = `Provide detailed nutritional information (calories, fat, protein, carbohydrates, fiber, vitamins, minerals) for ${food}. Format your response as a JSON object.`;
        console.log(`Prompt being sent to Gemini: ${prompt}`);

        const result = await model.generateContent(prompt);
        const response = await result.response;
        const text = response.text();
        console.log(`Raw Gemini API response: ${text}`);

       // Remove ```json and ``` from the response
        const cleanedText = text.replace(/```json|```/g, '');

        let nutritionData;
        try {
            nutritionData = JSON.parse(cleanedText);
        } catch (error) {
            console.error("Error parsing JSON from Gemini:", error);
            console.error("Raw Gemini Output:", text); // Log the raw output for debugging
            return res.status(500).json({
                error: "Error parsing nutritional information from Gemini.",
                rawOutput: text,
                parseError: error.message,
            });
        }

        res.json(nutritionData);

    } catch (error) {
        console.error("Error in /api/nutrition:", error);
        console.error("Gemini API Key", process.env.GEMINI_API_KEY);
        res.status(500).json({
            error: "Error fetching nutritional information from Gemini.",
            details: error.message,
        });
    }
});

// Meal Planner Endpoint
app.get('/api/mealplan', async (req, res) => {
    if (!genAI) {
        return res.status(500).json({
            error: "Gemini API key is not configured.  Cannot call the Gemini API."
        });
    }
    const {
        restrictions,
        allergies,
        health,
        preferences
    } = req.query;
    console.log(`Received meal plan request with: restrictions=${restrictions}, allergies=${allergies}, health=${health}, preferences=${preferences}`);

    if (!restrictions && !allergies && !health && !preferences) {
        return res.status(400).json({
            error: "At least one dietary parameter is required."
        });
    }

    try {
        const model = genAI.getGenerativeModel({
            model: "gemini-pro"
        });
        const prompt = `Create a 7-day personalized meal plan considering the following: Dietary Restrictions: ${restrictions || 'None'}, Allergies: ${allergies || 'None'}, Health Conditions: ${health || 'None'}, Taste Preferences: ${preferences || 'None'}. Provide the meal plan as a JSON object where each day is a key containing the breakfast, lunch, and dinner.`;
        console.log(`Prompt being sent to Gemini: ${prompt}`);

        const result = await model.generateContent(prompt);
        const response = await result.response;
        const text = response.text();
        console.log(`Raw Gemini API response: ${text}`);

       // Remove ```json and ``` from the response
        const cleanedText = text.replace(/```json|```/g, '');

        let mealPlanData;
        try {
            mealPlanData = JSON.parse(cleanedText);
        } catch (error) {
            console.error("Error parsing JSON from Gemini:", error);
            console.error("Raw Gemini Output:", text);
            return res.status(500).json({
                error: "Error parsing meal plan from Gemini.",
                rawOutput: text,
                parseError: error.message,
            });
        }

        res.json(mealPlanData);

    } catch (error) {
        console.error("Error in /api/mealplan:", error);
        res.status(500).json({
            error: "Error fetching meal plan from Gemini.",
            details: error.message,
        });
    }
});

app.listen(port, () => {
    console.log(`Server listening at http://localhost:${port}`);
});